"""Calibration helpers for HoundMind."""
