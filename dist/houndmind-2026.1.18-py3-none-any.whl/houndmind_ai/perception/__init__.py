"""Sensor fusion and perception helpers."""
