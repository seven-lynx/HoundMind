"""Hardware abstraction layer for PiDog."""
