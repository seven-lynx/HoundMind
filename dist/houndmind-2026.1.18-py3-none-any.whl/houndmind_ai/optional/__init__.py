"""Optional subsystems (vision, voice, face recognition)."""
