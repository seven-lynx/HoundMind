"""Logging utilities and event logging."""
