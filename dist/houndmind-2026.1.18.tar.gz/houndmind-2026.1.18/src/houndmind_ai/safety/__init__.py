"""Safety overrides and guard rails."""
