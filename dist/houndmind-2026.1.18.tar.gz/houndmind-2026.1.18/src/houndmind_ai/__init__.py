"""PiDog modular AI framework."""

__all__ = ["main"]
