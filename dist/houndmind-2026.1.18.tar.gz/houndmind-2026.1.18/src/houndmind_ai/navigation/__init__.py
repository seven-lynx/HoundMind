"""Navigation and obstacle avoidance modules."""
